import { Component } from '@angular/core';

@Component({
  selector: 'ngx-teileinfo',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class TeileinfoComponent {
}


