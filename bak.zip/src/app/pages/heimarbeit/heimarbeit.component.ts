import { Component } from '@angular/core';

@Component({
  selector: 'ngx-heimarbeit',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class HeimarbeitComponent {
}


