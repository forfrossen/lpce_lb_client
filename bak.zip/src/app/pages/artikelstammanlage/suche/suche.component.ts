import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'suche',
  templateUrl: './suche.component.html',
  styleUrls: ['./suche.component.scss']
})
export class SucheComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
