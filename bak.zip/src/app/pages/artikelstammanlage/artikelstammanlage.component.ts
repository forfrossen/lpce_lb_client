import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'artikelstammanlage',
  templateUrl: './artikelstammanlage.component.html',
  styleUrls: ['./artikelstammanlage.component.scss']
})
export class ArtikelstammanlageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
