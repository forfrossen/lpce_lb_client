export const BASE_URL = 'http://qcd480w04:3000';
export const API_VERSION = 'api';